View(penguins)
#Here's an example of a variable
first_variable <- "This is my variable"
second_variable <- 12.5

#Our first calculations

quarter_1_sales <- 36557.98
quarter_2_sales <- 43810.55
midyear_sales <- quarter_1_sales + quarter_2_sales
yearend_sales <- midyear_sales * 2
