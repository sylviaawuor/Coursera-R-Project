#Our first calculations

quarter_1_sales <- 36557.98
quarter_2_sales <- 43810.55
midyear_sales <- quarter_1_sales + quarter_2_sales
yearend_sales <- midyear_sales * 2

